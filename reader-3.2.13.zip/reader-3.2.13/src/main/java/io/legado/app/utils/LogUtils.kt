@file:Suppress("unused")

package io.legado.app.utils

fun Throwable.printOnDebug() {
    printStackTrace()
}
