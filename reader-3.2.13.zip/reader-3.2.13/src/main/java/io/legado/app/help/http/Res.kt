package io.legado.app.help.http

data class Res(val url: String, val body: String?)