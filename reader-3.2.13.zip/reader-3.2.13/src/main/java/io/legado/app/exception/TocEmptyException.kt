package io.legado.app.exception

/**
 * 目录为空
 */
class TocEmptyException(msg: String) : NoStackTraceException(msg)