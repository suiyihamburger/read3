# 文件结构介绍

* constant 常量
* data 数据
* help 帮助
* lib 库
* model 解析
