package me.ag2s.epublib.domain;

public interface ManifestProperties {

  String getName();
}
