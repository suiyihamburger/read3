package com.htmake.reader.entity

data class Size(
        val width: Double,
        val height: Double
)